#ifndef __DEMO_H
#define __DEMO_H
#include "stm32f10x.h"
extern u8 OLED_Clear_Flag;


#endif
